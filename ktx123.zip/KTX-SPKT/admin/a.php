<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	  <link href="/shoponi/view/font/Font Awesome/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="template/cssfont.css" rel="stylesheet">
  <link href="template/css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body>
	<div class="m-auto">
		Đây là trang ADMIN Ký Túc Xá - Đại Học Sư Phạm Kỹ Thuật !!!
	</div>
</body>
</html>