 <div class="container-fluid">
        <dir class="row">
            <div class="col-2 nenbac" style="margin-left: -20px">
                    <nav id="menu">      
                        <ul>
                            <h3> Sinh Viên </h3> 
                                    <li><a href="index.php?action=login">Đăng nhập</a></li>
                                    <li><a href="index.php?action=capnhapthongtin">Cập Nhập Thông Tin</a></li>
                                    <li><a href="index.php?action=dkphong">Đăng Ký Phòng</a></li>
                                    <li><a href="index.php?action=chuyenphong">ĐK Chuyển Phòng</a></li>
                                    <li><a href="index.php?action=traphong">Trả Phòng</a></li>
                                    <li><a href="index.php?action=tracucphong">Tra cứu Phòng</a></li>
                                    <li><a href="index.php?action=phongdango">Xem Phòng Đang Ở</a></li>
                                    <li><a href="index.php?action=xemthongbao">Xem Thông Báo</a></li>
                                    <li><a href="index.php?action=logout">Đăng Xuất</a></li>
                        </ul>        
                      </nav>
            </div>
            <div class="col-8 ">
                <?php include_once('include/content.php'); ?>
            </div>
            <div class="col-2 nenbac">
               <div >   
                    <img src="images/logo.jpg" width="200" 
                         alt="Activities Board">
                    <center><h2><a href="http://ute.udn.vn/Tin-Tuc.aspx" class="no_underline">
                        Tin tức UTE</center>
                    </a></h2>
                    <p class="news_item">Ký Túc Xá sẽ mở cửa phục vụ sinh viên ....</p>
                </div>

            </div>
        </dir>        
    </div>