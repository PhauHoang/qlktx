		<h6 class="text-center">Thêm Nhân viên Mới</h6>
<table class="table table-hover text-center ">
	<form action="quanlynhanvien/xuly.php" method="get" accept-charset="utf-8">
		<thead>
			<tr>
				<th>Mã NV</th><th>Họ Tên</th><th>Ngày Sinh</th><th>Địa Chỉ</th><th>SĐT</th><th>Mật Khẩu</th><th>Quyền</th><th>#</th>
			</tr>
		</thead>
		<tbody>			
				<tr>
					<td><input  class="form-control form-control-sm" type="text"  name="manv" ></td>
					<td><input  class="form-control form-control-sm" type="text" name="ten" ></td>
					<td><input  class="form-control form-control-sm" type="date" name="ns" ></td>
					<td><input  class="form-control form-control-sm" type="text" name="dc" ></td>
					<td><input  class="form-control form-control-sm" type="text" name="sdt" ></td>
					<td><input  class="form-control form-control-sm" type="text" name="pass" ></td>
					<td><input  class="form-control form-control-sm" type="text" name="q" ></td>
					<td><input  class="btn-sm btn-success btn" type="submit" name="action" value="them"></td>
				</tr>	
		</tbody>
</table>
</form>	<br><hr>